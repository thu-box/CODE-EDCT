%-------------------------------------------------------------
%
%    Copyright (C) 2006 Krister Svanberg
%
%    This file, subsolv.m, is part of GCMMA-MMA-code.
%    
%    GCMMA-MMA-code is free software; you can redistribute it and/or
%    modify it under the terms of the GNU General Public License as 
%    published by the Free Software Foundation; either version 3 of 
%    the License, or (at your option) any later version.
%    
%    This code is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%    
%    You should have received a copy of the GNU General Public License
%    (file COPYING) along with this file.  If not, see 
%    <http://www.gnu.org/licenses/>.
%    
%    You should have received a file README along with this file,
%    containing contact information.  If not, see
%    <http://www.smoptit.se/> or e-mail mmainfo@smoptit.se or krille@math.kth.se.
%
%    Version Dec 2006.
%
%
function [xmma,ymma,zmma,lamma,xsimma,etamma,mumma,zetmma,smma] = ...
subsolv(m,n,epsimin,low,upp,alfa,beta,p0,q0,P,Q,a0,a,b,c,d);
%
% This function subsolv solves the MMA subproblem:
%         
% minimize   SUM[ p0j/(uppj-xj) + q0j/(xj-lowj) ] + a0*z +
%          + SUM[ ci*yi + 0.5*di*(yi)^2 ],
%
% subject to SUM[ pij/(uppj-xj) + qij/(xj-lowj) ] - ai*z - yi <= bi,
%            alfaj <=  xj <=  betaj,  yi >= 0,  z >= 0.
%        
% Input:  m, n, low, upp, alfa, beta, p0, q0, P, Q, a0, a, b, c, d.
% Output: xmma,ymma,zmma, slack variables and Lagrange multiplers.


epsi = 1;

x = 0.5*(alfa+beta);
y = ones(m,1);
z = 1;
lam = ones(m,1);
xsi = max(1./(x-alfa), 1);
eta = max(1./(beta-x), 1);
mu = max(0.5*c, 1);
zet = 1;
s = ones(m,1);
itera = 0;

P_trans = P';
Q_trans = Q';
a_col = a(:);

while epsi > epsimin
    epsvecn = epsi;
    epsvecm = epsi;
    
    ux1 = upp - x;
    xl1 = x - low;
    ux2 = ux1.^2;
    xl2 = xl1.^2;
    uxinv1 = 1./ux1;
    xlinv1 = 1./xl1;
    
    plam = p0 + P_trans * lam;
    qlam = q0 + Q_trans * lam;
    gvec = P * uxinv1 + Q * xlinv1;
    dpsidx = plam./ux2 - qlam./xl2;
    
    rex = dpsidx - xsi + eta;
    rey = c + d.*y - mu - lam;
    rez = a0 - zet - a_col'*lam;
    relam = gvec - a_col*z - y + s - b;
    rexsi = xsi.*(x-alfa) - epsvecn;
    reeta = eta.*(beta-x) - epsvecn;
    remu = mu.*y - epsvecm;
    rezet = zet*z - epsi;
    res = lam.*s - epsvecm;
    
    residu1 = [rex; rey; rez];
    residu2 = [relam; rexsi; reeta; remu; rezet; res];
    residu = [residu1; residu2];
    residunorm = norm(residu);
    residumax = max(abs(residu));
    
    ittt = 0;
    while residumax > 0.9*epsi && ittt < 200
        ittt = ittt + 1;
        itera = itera + 1;
        
        ux1 = upp - x;
        xl1 = x - low;
        ux2 = ux1.^2;
        xl2 = xl1.^2;
        ux3 = ux1.^3;
        xl3 = xl1.^3;
        uxinv1 = 1./ux1;
        xlinv1 = 1./xl1;
        uxinv2 = 1./ux2;
        xlinv2 = 1./xl2;
        
        plam = p0 + P_trans * lam;
        qlam = q0 + Q_trans * lam;
        gvec = P * uxinv1 + Q * xlinv1;
        
        GG = P .* uxinv2' - Q .* xlinv2';
        GG_trans = GG';
        
        dpsidx = plam./ux2 - qlam./xl2;
        delx = dpsidx - epsvecn./(x-alfa) + epsvecn./(beta-x);
        dely = c + d.*y - lam - epsvecm./y;
        delz = a0 - a_col'*lam - epsi/z;
        dellam = gvec - a_col*z - y - b + epsvecm./lam;
        
        diagx = plam./ux3 + qlam./xl3;
        diagx = 2*diagx + xsi./(x-alfa) + eta./(beta-x);
        diagxinv = 1./diagx;
        diagy = d + mu./y;
        diagyinv = 1./diagy;
        diaglam = s./lam;
        diaglamyi = diaglam + diagyinv;
        
        if m < n
            blam = dellam + dely./diagy - GG*(delx./diagx);
            bb = [blam; delz];
            
            Alam = diag(diaglamyi) + (GG .* diagxinv') * GG_trans;
            AA = [Alam,     a_col
                  a_col', -zet/z];
            
            solut = AA\bb;
            dlam = solut(1:m);
            dz = solut(m+1);
            dx = -delx./diagx - (GG_trans*dlam)./diagx;
        else
            diaglamyiinv = 1./diaglamyi;
            dellamyi = dellam + dely./diagy;
            
            Axx = diag(diagx) + (GG_trans .* diaglamyiinv') * GG;
            azz = zet/z + a_col'*(a_col./diaglamyi);
            axz = -GG_trans*(a_col./diaglamyi);
            
            bx = delx + GG_trans*(dellamyi./diaglamyi);
            bz = delz - a_col'*(dellamyi./diaglamyi);
            
            AA = [Axx,   axz
                  axz',  azz];
            bb = [-bx; -bz];
            
            solut = AA\bb;
            dx = solut(1:n);
            dz = solut(n+1);
            dlam = (GG*dx)./diaglamyi - dz*(a_col./diaglamyi) + dellamyi./diaglamyi;
        end
        
        dy = -dely./diagy + dlam./diagy;
        dxsi = -xsi + epsvecn./(x-alfa) - (xsi.*dx)./(x-alfa);
        deta = -eta + epsvecn./(beta-x) + (eta.*dx)./(beta-x);
        dmu = -mu + epsvecm./y - (mu.*dy)./y;
        dzet = -zet + epsi/z - zet*dz/z;
        ds = -s + epsvecm./lam - (s.*dlam)./lam;
        
        xx = [y; z; lam; xsi; eta; mu; zet; s];
        dxx = [dy; dz; dlam; dxsi; deta; dmu; dzet; ds];
        
        stepxx = -1.01*dxx./xx;
        stmxx = max(stepxx);
        stepalfa = -1.01*dx./(x-alfa);
        stmalfa = max(stepalfa);
        stepbeta = 1.01*dx./(beta-x);
        stmbeta = max(stepbeta);
        stmalbe = max(stmalfa, stmbeta);
        stmalbexx = max(stmalbe, stmxx);
        stminv = max(stmalbexx, 1);
        steg = 1/stminv;
        
        xold = x; yold = y; zold = z; lamold = lam;
        xsiold = xsi; etaold = eta; muold = mu; zetold = zet; sold = s;
        
        % 线搜索
        itto = 0;
        resinew = 2*residunorm;
        while resinew > residunorm && itto < 50
            itto = itto + 1;
            
            x = xold + steg*dx;
            y = yold + steg*dy;
            z = zold + steg*dz;
            lam = lamold + steg*dlam;
            xsi = xsiold + steg*dxsi;
            eta = etaold + steg*deta;
            mu = muold + steg*dmu;
            zet = zetold + steg*dzet;
            s = sold + steg*ds;
            
            ux1 = upp - x;
            xl1 = x - low;
            uxinv1 = 1./ux1;
            xlinv1 = 1./xl1;
            
            plam = p0 + P_trans * lam;
            qlam = q0 + Q_trans * lam;
            gvec = P * uxinv1 + Q * xlinv1;
            dpsidx = plam./(ux1.^2) - qlam./(xl1.^2);
            
            rex = dpsidx - xsi + eta;
            rey = c + d.*y - mu - lam;
            rez = a0 - zet - a_col'*lam;
            relam = gvec - a_col*z - y + s - b;
            rexsi = xsi.*(x-alfa) - epsvecn;
            reeta = eta.*(beta-x) - epsvecn;
            remu = mu.*y - epsvecm;
            rezet = zet*z - epsi;
            res = lam.*s - epsvecm;
            
            residu1 = [rex; rey; rez];
            residu2 = [relam; rexsi; reeta; remu; rezet; res];
            residu = [residu1; residu2];
            resinew = norm(residu);
            
            steg = steg/2;
        end
        
        residunorm = resinew;
        residumax = max(abs(residu));
        steg = 2*steg;
    end
    
    if ittt > 198
        epsi
        ittt
    end
    
    epsi = 0.1*epsi;
end

xmma = x;
ymma = y;
zmma = z;
lamma = lam;
xsimma = xsi;
etamma = eta;
mumma = mu;
zetmma = zet;
smma = s;
end
%-------------------------------------------------------------

